.. code:: ipython3

    import pandas as pd
    import numpy as np
    import seaborn as sns
    import matplotlib.pyplot as plt
    !conda install -y -c anaconda seaborn=0.9.0


.. parsed-literal::

    ^C
    

.. code:: ipython3

    data = pd.read_csv(r"C:\Users\shant\Downloads\284_618_compressed_vgsales.csv.zip")

.. code:: ipython3

    data




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Rank</th>
          <th>Name</th>
          <th>Platform</th>
          <th>Year</th>
          <th>Genre</th>
          <th>Publisher</th>
          <th>NA_Sales</th>
          <th>EU_Sales</th>
          <th>JP_Sales</th>
          <th>Other_Sales</th>
          <th>Global_Sales</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>Wii Sports</td>
          <td>Wii</td>
          <td>2006.0</td>
          <td>Sports</td>
          <td>Nintendo</td>
          <td>41.49</td>
          <td>29.02</td>
          <td>3.77</td>
          <td>8.46</td>
          <td>82.74</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>Super Mario Bros.</td>
          <td>NES</td>
          <td>1985.0</td>
          <td>Platform</td>
          <td>Nintendo</td>
          <td>29.08</td>
          <td>3.58</td>
          <td>6.81</td>
          <td>0.77</td>
          <td>40.24</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>Mario Kart Wii</td>
          <td>Wii</td>
          <td>2008.0</td>
          <td>Racing</td>
          <td>Nintendo</td>
          <td>15.85</td>
          <td>12.88</td>
          <td>3.79</td>
          <td>3.31</td>
          <td>35.82</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>Wii Sports Resort</td>
          <td>Wii</td>
          <td>2009.0</td>
          <td>Sports</td>
          <td>Nintendo</td>
          <td>15.75</td>
          <td>11.01</td>
          <td>3.28</td>
          <td>2.96</td>
          <td>33.00</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>Pokemon Red/Pokemon Blue</td>
          <td>GB</td>
          <td>1996.0</td>
          <td>Role-Playing</td>
          <td>Nintendo</td>
          <td>11.27</td>
          <td>8.89</td>
          <td>10.22</td>
          <td>1.00</td>
          <td>31.37</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>16593</th>
          <td>16596</td>
          <td>Woody Woodpecker in Crazy Castle 5</td>
          <td>GBA</td>
          <td>2002.0</td>
          <td>Platform</td>
          <td>Kemco</td>
          <td>0.01</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
        <tr>
          <th>16594</th>
          <td>16597</td>
          <td>Men in Black II: Alien Escape</td>
          <td>GC</td>
          <td>2003.0</td>
          <td>Shooter</td>
          <td>Infogrames</td>
          <td>0.01</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
        <tr>
          <th>16595</th>
          <td>16598</td>
          <td>SCORE International Baja 1000: The Official Game</td>
          <td>PS2</td>
          <td>2008.0</td>
          <td>Racing</td>
          <td>Activision</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
        <tr>
          <th>16596</th>
          <td>16599</td>
          <td>Know How 2</td>
          <td>DS</td>
          <td>2010.0</td>
          <td>Puzzle</td>
          <td>7G//AMES</td>
          <td>0.00</td>
          <td>0.01</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
        <tr>
          <th>16597</th>
          <td>16600</td>
          <td>Spirits &amp; Spells</td>
          <td>GBA</td>
          <td>2003.0</td>
          <td>Platform</td>
          <td>Wanadoo</td>
          <td>0.01</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
      </tbody>
    </table>
    <p>16598 rows × 11 columns</p>
    </div>



.. code:: ipython3

    data.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Rank</th>
          <th>Name</th>
          <th>Platform</th>
          <th>Year</th>
          <th>Genre</th>
          <th>Publisher</th>
          <th>NA_Sales</th>
          <th>EU_Sales</th>
          <th>JP_Sales</th>
          <th>Other_Sales</th>
          <th>Global_Sales</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>Wii Sports</td>
          <td>Wii</td>
          <td>2006.0</td>
          <td>Sports</td>
          <td>Nintendo</td>
          <td>41.49</td>
          <td>29.02</td>
          <td>3.77</td>
          <td>8.46</td>
          <td>82.74</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>Super Mario Bros.</td>
          <td>NES</td>
          <td>1985.0</td>
          <td>Platform</td>
          <td>Nintendo</td>
          <td>29.08</td>
          <td>3.58</td>
          <td>6.81</td>
          <td>0.77</td>
          <td>40.24</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>Mario Kart Wii</td>
          <td>Wii</td>
          <td>2008.0</td>
          <td>Racing</td>
          <td>Nintendo</td>
          <td>15.85</td>
          <td>12.88</td>
          <td>3.79</td>
          <td>3.31</td>
          <td>35.82</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>Wii Sports Resort</td>
          <td>Wii</td>
          <td>2009.0</td>
          <td>Sports</td>
          <td>Nintendo</td>
          <td>15.75</td>
          <td>11.01</td>
          <td>3.28</td>
          <td>2.96</td>
          <td>33.00</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>Pokemon Red/Pokemon Blue</td>
          <td>GB</td>
          <td>1996.0</td>
          <td>Role-Playing</td>
          <td>Nintendo</td>
          <td>11.27</td>
          <td>8.89</td>
          <td>10.22</td>
          <td>1.00</td>
          <td>31.37</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    data.columns




.. parsed-literal::

    Index(['Rank', 'Name', 'Platform', 'Year', 'Genre', 'Publisher', 'NA_Sales',
           'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales'],
          dtype='object')



.. code:: ipython3

    data.describe




.. parsed-literal::

    <bound method NDFrame.describe of         Rank                                              Name Platform  \
    0          1                                        Wii Sports      Wii   
    1          2                                 Super Mario Bros.      NES   
    2          3                                    Mario Kart Wii      Wii   
    3          4                                 Wii Sports Resort      Wii   
    4          5                          Pokemon Red/Pokemon Blue       GB   
    ...      ...                                               ...      ...   
    16593  16596                Woody Woodpecker in Crazy Castle 5      GBA   
    16594  16597                     Men in Black II: Alien Escape       GC   
    16595  16598  SCORE International Baja 1000: The Official Game      PS2   
    16596  16599                                        Know How 2       DS   
    16597  16600                                  Spirits & Spells      GBA   
    
             Year         Genre   Publisher  NA_Sales  EU_Sales  JP_Sales  \
    0      2006.0        Sports    Nintendo     41.49     29.02      3.77   
    1      1985.0      Platform    Nintendo     29.08      3.58      6.81   
    2      2008.0        Racing    Nintendo     15.85     12.88      3.79   
    3      2009.0        Sports    Nintendo     15.75     11.01      3.28   
    4      1996.0  Role-Playing    Nintendo     11.27      8.89     10.22   
    ...       ...           ...         ...       ...       ...       ...   
    16593  2002.0      Platform       Kemco      0.01      0.00      0.00   
    16594  2003.0       Shooter  Infogrames      0.01      0.00      0.00   
    16595  2008.0        Racing  Activision      0.00      0.00      0.00   
    16596  2010.0        Puzzle    7G//AMES      0.00      0.01      0.00   
    16597  2003.0      Platform     Wanadoo      0.01      0.00      0.00   
    
           Other_Sales  Global_Sales  
    0             8.46         82.74  
    1             0.77         40.24  
    2             3.31         35.82  
    3             2.96         33.00  
    4             1.00         31.37  
    ...            ...           ...  
    16593         0.00          0.01  
    16594         0.00          0.01  
    16595         0.00          0.01  
    16596         0.00          0.01  
    16597         0.00          0.01  
    
    [16598 rows x 11 columns]>



.. code:: ipython3

    data.isnull().sum()




.. parsed-literal::

    Rank              0
    Name              0
    Platform          0
    Year            271
    Genre             0
    Publisher        58
    NA_Sales          0
    EU_Sales          0
    JP_Sales          0
    Other_Sales       0
    Global_Sales      0
    dtype: int64



Relating variables with Scatterplots
====================================

.. code:: ipython3

    sns.pairplot(data)




.. parsed-literal::

    <seaborn.axisgrid.PairGrid at 0x2b4ca8ecc40>




.. image:: output_8_1.png


.. code:: ipython3

    data.groupby("Genre").sum()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Rank</th>
          <th>Year</th>
          <th>NA_Sales</th>
          <th>EU_Sales</th>
          <th>JP_Sales</th>
          <th>Other_Sales</th>
          <th>Global_Sales</th>
        </tr>
        <tr>
          <th>Genre</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Action</th>
          <td>26441383</td>
          <td>6531731.0</td>
          <td>877.83</td>
          <td>525.00</td>
          <td>159.95</td>
          <td>187.38</td>
          <td>1751.18</td>
        </tr>
        <tr>
          <th>Adventure</th>
          <td>14831165</td>
          <td>2562375.0</td>
          <td>105.80</td>
          <td>64.13</td>
          <td>52.07</td>
          <td>16.81</td>
          <td>239.04</td>
        </tr>
        <tr>
          <th>Fighting</th>
          <td>6484242</td>
          <td>1675871.0</td>
          <td>223.59</td>
          <td>101.32</td>
          <td>87.35</td>
          <td>36.68</td>
          <td>448.91</td>
        </tr>
        <tr>
          <th>Misc</th>
          <td>14889052</td>
          <td>3432412.0</td>
          <td>410.24</td>
          <td>215.98</td>
          <td>107.76</td>
          <td>75.32</td>
          <td>809.96</td>
        </tr>
        <tr>
          <th>Platform</th>
          <td>6137545</td>
          <td>1755347.0</td>
          <td>447.05</td>
          <td>201.63</td>
          <td>130.77</td>
          <td>51.59</td>
          <td>831.37</td>
        </tr>
        <tr>
          <th>Puzzle</th>
          <td>5603136</td>
          <td>1144994.0</td>
          <td>123.78</td>
          <td>50.78</td>
          <td>57.31</td>
          <td>12.55</td>
          <td>244.95</td>
        </tr>
        <tr>
          <th>Racing</th>
          <td>9943933</td>
          <td>2457934.0</td>
          <td>359.42</td>
          <td>238.39</td>
          <td>56.69</td>
          <td>77.27</td>
          <td>732.04</td>
        </tr>
        <tr>
          <th>Role-Playing</th>
          <td>12032228</td>
          <td>2952379.0</td>
          <td>327.28</td>
          <td>188.06</td>
          <td>352.31</td>
          <td>59.61</td>
          <td>927.37</td>
        </tr>
        <tr>
          <th>Shooter</th>
          <td>9653872</td>
          <td>2571588.0</td>
          <td>582.60</td>
          <td>313.27</td>
          <td>38.28</td>
          <td>102.69</td>
          <td>1037.37</td>
        </tr>
        <tr>
          <th>Simulation</th>
          <td>7478816</td>
          <td>1707589.0</td>
          <td>183.31</td>
          <td>113.38</td>
          <td>63.70</td>
          <td>31.52</td>
          <td>392.20</td>
        </tr>
        <tr>
          <th>Sports</th>
          <td>17419112</td>
          <td>4620621.0</td>
          <td>683.35</td>
          <td>376.85</td>
          <td>135.37</td>
          <td>134.97</td>
          <td>1330.93</td>
        </tr>
        <tr>
          <th>Strategy</th>
          <td>6858962</td>
          <td>1345757.0</td>
          <td>68.70</td>
          <td>45.34</td>
          <td>49.46</td>
          <td>11.36</td>
          <td>175.12</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    data.groupby('Name').sum()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Rank</th>
          <th>Year</th>
          <th>NA_Sales</th>
          <th>EU_Sales</th>
          <th>JP_Sales</th>
          <th>Other_Sales</th>
          <th>Global_Sales</th>
        </tr>
        <tr>
          <th>Name</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>'98 Koshien</th>
          <td>4756</td>
          <td>1998.0</td>
          <td>0.15</td>
          <td>0.10</td>
          <td>0.12</td>
          <td>0.03</td>
          <td>0.41</td>
        </tr>
        <tr>
          <th>.hack//G.U. Vol.1//Rebirth</th>
          <td>8359</td>
          <td>2006.0</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.17</td>
          <td>0.00</td>
          <td>0.17</td>
        </tr>
        <tr>
          <th>.hack//G.U. Vol.2//Reminisce</th>
          <td>7109</td>
          <td>2006.0</td>
          <td>0.11</td>
          <td>0.09</td>
          <td>0.00</td>
          <td>0.03</td>
          <td>0.23</td>
        </tr>
        <tr>
          <th>.hack//G.U. Vol.2//Reminisce (jp sales)</th>
          <td>8604</td>
          <td>2006.0</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.16</td>
          <td>0.00</td>
          <td>0.16</td>
        </tr>
        <tr>
          <th>.hack//G.U. Vol.3//Redemption</th>
          <td>8306</td>
          <td>2007.0</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.17</td>
          <td>0.00</td>
          <td>0.17</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>thinkSMART: Chess for Kids</th>
          <td>16417</td>
          <td>2011.0</td>
          <td>0.01</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.01</td>
        </tr>
        <tr>
          <th>uDraw Studio</th>
          <td>628</td>
          <td>2010.0</td>
          <td>1.67</td>
          <td>0.58</td>
          <td>0.00</td>
          <td>0.20</td>
          <td>2.46</td>
        </tr>
        <tr>
          <th>uDraw Studio: Instant Artist</th>
          <td>23363</td>
          <td>4022.0</td>
          <td>0.09</td>
          <td>0.10</td>
          <td>0.00</td>
          <td>0.02</td>
          <td>0.21</td>
        </tr>
        <tr>
          <th>wwe Smackdown vs. Raw 2006</th>
          <td>471</td>
          <td>0.0</td>
          <td>1.57</td>
          <td>1.02</td>
          <td>0.00</td>
          <td>0.41</td>
          <td>3.00</td>
        </tr>
        <tr>
          <th>¡Shin Chan Flipa en colores!</th>
          <td>9137</td>
          <td>2007.0</td>
          <td>0.00</td>
          <td>0.00</td>
          <td>0.14</td>
          <td>0.00</td>
          <td>0.14</td>
        </tr>
      </tbody>
    </table>
    <p>11493 rows × 7 columns</p>
    </div>



